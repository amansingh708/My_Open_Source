package Day1;

import java.util.List;
import java.util.stream.Stream;

public class StreamExample {

	public static void main(String[] args) {

		List<String> courses = List.of("Spring", "Spring Boot", "API", "Microservices", "AWS", "AZURE", "Docker",
				"Kebernetes");

		long spaceCount = courses.stream().mapToLong(s -> s.chars().filter(Character::isWhitespace).count()).reduce(0,
				Long::sum);

		System.out.println(spaceCount);
		long spaceCount2 = courses.stream().flatMapToInt(s->s.chars()='').count();

		System.out.println(spaceCount2);
	}

}
