package FunctionalProgramming;

import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Stream;


public class LamdaExample {

	public static void main(String[] args) {
		
		List<String> courses= List.of("Spring","Spring Boot","API","Microservices", "AWS", "AZURE","Docker","Kebernetes");
		
		Stream<String> s1=courses.stream();
		
		Stream<String> s2=s1.sorted((t1,t2)-> t2.compareTo(t2));
		
		List<Integer> numbers= List.of(12,9,13,4,6,2,4,12,15);
		
		
		//Sum of all the string lengths
		Integer sum1= courses.stream().mapToInt(String::length).sum();
		
		
		
		
		Integer sum =numbers.stream().reduce(0, (Integer x, Integer y)->x+y);
		
		Supplier<Integer> randomSupplier =()->
		{
			
			Random rand= new Random();
			return rand.nextInt(1000);
		};
		
		System.out.println(randomSupplier.get());
		
		
		
		

	}

	private static Object reduce(Object object) {
		// TODO Auto-generated method stub
		return null;
	}

}
