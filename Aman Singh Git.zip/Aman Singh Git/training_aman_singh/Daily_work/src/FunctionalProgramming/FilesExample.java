package FunctionalProgramming;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Stream;

public class FilesExample {
	
	private static final String Main = null;

	public static void main(String...args) throws IOException 
	{
		
		//Stream<Path> dir = Files.list(Paths.get(".")).filter(Files::isDirectory).filter(Main::hasAtLeastOneFile).toList();
	}

	
}
