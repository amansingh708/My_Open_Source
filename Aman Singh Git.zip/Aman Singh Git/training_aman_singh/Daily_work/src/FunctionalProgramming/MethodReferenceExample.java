package FunctionalProgramming;

import java.util.List;

public class MethodReferenceExample {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> courses= List.of("Spring","Spring Boot","API","Microservices", "AWS", "AZURE","Docker","Kebernetes");
		
		courses.stream().forEach(System.out::println);

	}

}
