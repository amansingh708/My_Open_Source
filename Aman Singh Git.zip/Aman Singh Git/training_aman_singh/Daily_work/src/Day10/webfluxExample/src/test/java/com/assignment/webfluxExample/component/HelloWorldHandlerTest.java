package com.assignment.webfluxExample.component;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.reactive.server.WebTestClient;

@WebFluxTest
@Import({HelloWorldHandler.class, HelloWorldRouter.class})
public class HelloWorldHandlerTest {

    @Autowired
    private WebTestClient webTestClient;

    @Test
    public void testHelloWorld() {
        webTestClient.get()
                .uri("/hello")
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class)
                .isEqualTo("Hello, World!");
    }
}
