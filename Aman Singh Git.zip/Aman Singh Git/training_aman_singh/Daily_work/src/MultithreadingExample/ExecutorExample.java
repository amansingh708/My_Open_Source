package MultithreadingExample;

import java.time.Duration;
import java.time.LocalTime;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

public class ExecutorExample {

	public static void main(String[] args) {

		ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() - 2);
        
		System.out.println("Total capacity -"+ Runtime.getRuntime().availableProcessors());
		for (int i = 0; i < 50; i++) {
			Runnable r1 = new Runnable() {
				public void run() {
					LocalTime localTime = LocalTime.now();
					Integer[] numbers = new Integer[] { 1, 4, 3, 5 };

					Stream<Integer> s1 = Stream.of(numbers);
					s1.sorted((o1, o2) -> o2 - o1).limit(2).forEach(System.out::println);
					System.out.println(Thread.currentThread());
					long timeTaken = Duration.between(localTime, localTime.now()).toMillis();
					System.out.println(timeTaken);

				}
			};
			executor.execute(r1);

		}
		
		executor.shutdown();

	}
}
