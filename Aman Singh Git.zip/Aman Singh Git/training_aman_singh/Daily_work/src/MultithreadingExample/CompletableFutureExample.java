package MultithreadingExample;

import java.lang.System.Logger;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;



public class CompletableFutureExample {

	public static void main(String[] args) throws Exception {
		
		ExecutorService executorService =Executors.newSingleThreadExecutor();
		
		CompletableFuture<String> future =new CompletableFuture<>();
		
		executorService.submit(()->
		{
			TimeUnit.SECONDS.sleep(10);
			future.complete("value");
			return null;
		});
		
		while(!future.isDone()) 
		{
			TimeUnit.SECONDS.sleep(2);
			
		}
		
		String result=future.get();
		System.out.println("result:{}"+result);
		
		

	}

}
