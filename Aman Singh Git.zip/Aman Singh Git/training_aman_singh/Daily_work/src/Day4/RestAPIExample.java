//
//
////Required Repository and Models and Service has to be created !
//
////This is just an example of RestAPI 
//
//
//package Day4;
//
//import com.aman.demo.model.Book;
//import com.aman.demo.repository.BookRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.Optional;
//
//@RestController
//@RequestMapping("/api/books")
//public class BookController {
//
//    @Autowired
//    private BookRepository bookRepository;
//
//    // GET all books
//    @GetMapping
//    public List<Book> getAllBooks() {
//        return bookRepository.findAll();
//    }
//
//    // GET a book by ID
//    @GetMapping("/{id}")
//    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
//        Optional<Book> book = bookRepository.findById(id);
//        if (book.isPresent()) {
//            return ResponseEntity.ok(book.get());
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//    // POST a new book
//    @PostMapping
//    public Book createBook(@RequestBody Book book) {
//        return bookRepository.save(book);
//    }
//
//    // PUT update a book by ID
//    @PutMapping("/{id}")
//    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book bookDetails) {
//        Optional<Book> book = bookRepository.findById(id);
//        if (book.isPresent()) {
//            Book updatedBook = book.get();
//            updatedBook.setTitle(bookDetails.getTitle());
//            updatedBook.setAuthor(bookDetails.getAuthor());
//            return ResponseEntity.ok(bookRepository.save(updatedBook));
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//    // DELETE a book by ID
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
//        if (bookRepository.existsById(id)) {
//            bookRepository.deleteById(id);
//            return ResponseEntity.noContent().build();
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//}