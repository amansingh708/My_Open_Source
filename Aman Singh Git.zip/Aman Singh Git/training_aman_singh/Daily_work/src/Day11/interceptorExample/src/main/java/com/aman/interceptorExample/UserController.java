package com.aman.interceptorExample;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @GetMapping("/users")
    public String getUsers() {
        return "List of users";
    }
    
    @GetMapping("/users/{id}")
    public String getUserById() {
        return "UserId is 23";
    }
    
    @GetMapping("/home")
    public String home() {
        return "Home page";
    }
}
