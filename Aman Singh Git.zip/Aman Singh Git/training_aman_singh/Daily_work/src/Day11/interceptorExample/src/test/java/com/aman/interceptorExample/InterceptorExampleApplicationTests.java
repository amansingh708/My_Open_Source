package com.aman.interceptorExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterceptorExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
