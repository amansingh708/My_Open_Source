package com.aman.interceptorExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterceptorExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterceptorExampleApplication.class, args);
	}

}
