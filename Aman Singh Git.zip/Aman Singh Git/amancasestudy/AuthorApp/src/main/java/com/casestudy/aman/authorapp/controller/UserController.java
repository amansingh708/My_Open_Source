package com.casestudy.aman.authorapp.controller;

import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.aman.authorapp.entity.User;
import com.casestudy.aman.authorapp.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	
	org.slf4j.Logger logger = LoggerFactory.getLogger(UserController.class);


    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public User registerUser(@RequestBody User user) {
    	logger.debug("saving order in controller");
        return userService.registerUser(user);
        //logger.debug("saving order in controller");
    }

    
    @GetMapping("/{id}")
    public Optional<User> getUserById(@PathVariable Long id) {
        return userService.getUserById(id);
    }
    
    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User userDetails) {
        User user = userService.getUserById(id)
                .orElseThrow(() ->new RuntimeException("User not found with id " + id));
        
        user.setUsername(userDetails.getUsername());
       user.setPassword(userDetails.getPassword());
       user.setEmail(userDetails.getEmail());
        
        return userService.updateUser(user);
    }
    
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUserById(id);
        } catch (EmptyResultDataAccessException e) {
            throw new RuntimeException("User not found with id " + id);
        }
    }
}