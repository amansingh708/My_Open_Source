package com.casestudy.aman.authorapp.service;

import java.util.List;

import com.casestudy.aman.authorapp.entity.Author;

public interface FavoriteService {
    void addAuthorToFavorites(Long userId, Long authorId);
    List<Author> getFavoriteAuthors(Long userId);
    void removeAuthorFromFavorites(Long userId, Long authorId); 
}
