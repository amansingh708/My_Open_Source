package com.casestudy.aman.authorapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorApp {

	public static void main(String[] args) {
		SpringApplication.run(AuthorApp.class, args);
	}

}
