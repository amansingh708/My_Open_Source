package com.casestudy.aman.authorapp.service;

import java.util.List;
import java.util.Optional;

import com.casestudy.aman.authorapp.entity.Author;
import com.casestudy.aman.authorapp.entity.User;

public interface AuthorService {
	
	    Author saveAuthor(Author author);
	    Optional<Author> getAuthorById(Long id);
	    Author updateAuthor(Author author);
	    void deleteAuthorById(Long id);
	}
