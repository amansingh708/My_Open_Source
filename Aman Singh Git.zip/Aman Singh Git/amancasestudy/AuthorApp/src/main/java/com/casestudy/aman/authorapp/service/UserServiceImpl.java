package com.casestudy.aman.authorapp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.aman.authorapp.entity.User;
import com.casestudy.aman.authorapp.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	@Override
	public User registerUser(User user) {
		if (userRepository.findByUsername(user.getUsername()).isPresent()) {
			throw new RuntimeException("User with this username already exists");
		}
		userRepository.save(user);
		return user;
	}

    @Override
	public Optional<User> getUserById(Long id) {
		return Optional.of(userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found")));
	}

	@Override
	public User updateUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public void deleteUserById(Long id) {
		userRepository.deleteById(id);
	}
	

}
