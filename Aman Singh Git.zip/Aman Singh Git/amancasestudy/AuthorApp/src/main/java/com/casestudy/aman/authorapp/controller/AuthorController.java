package com.casestudy.aman.authorapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.aman.authorapp.entity.Author;
import com.casestudy.aman.authorapp.entity.User;
import com.casestudy.aman.authorapp.service.AuthorService;

@RestController
@RequestMapping("/authors")
public class AuthorController{
	@Autowired
	private AuthorService authorService;

	@PostMapping("/add")
	public Author addAuthor(@RequestBody Author author) {
		return authorService.saveAuthor(author);
	}

	@GetMapping("/{id}")
	public Optional<Author> getAuthorById(@PathVariable Long id) {
		return authorService.getAuthorById(id);
	}
	 
	 @PutMapping("/{id}")
	    public Author updateAuthor(@PathVariable Long id, @RequestBody Author authorDetails) {
	        Author author = authorService.getAuthorById(id)
	                .orElseThrow(() ->new RuntimeException("Author not found with id " + id));
	        
	        author.setName(authorDetails.getName());
	        author.setBio(authorDetails.getBio());
	        author.setGenre(authorDetails.getGenre());
	        
	        return authorService.updateAuthor(author);
	    }

	@DeleteMapping("/{id}")
	public String deleteAuthor(@PathVariable Long id) {
		authorService.deleteAuthorById(id);
		return "Entry Deleted";
	}
}