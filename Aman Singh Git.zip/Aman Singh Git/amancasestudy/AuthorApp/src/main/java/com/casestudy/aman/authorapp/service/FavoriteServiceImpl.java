package com.casestudy.aman.authorapp.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.aman.authorapp.entity.Author;
import com.casestudy.aman.authorapp.entity.Favorite;
import com.casestudy.aman.authorapp.entity.User;
import com.casestudy.aman.authorapp.repository.AuthorRepository;
import com.casestudy.aman.authorapp.repository.FavoriteRepository;
import com.casestudy.aman.authorapp.repository.UserRepository;

@Service
public class FavoriteServiceImpl implements FavoriteService {

	@Autowired
	private FavoriteRepository favoriteRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AuthorRepository authorRepository;

	@Override 
	public void addAuthorToFavorites(Long userId, Long authorId) {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("User not found with id " + userId));

		Author author = authorRepository.findById(authorId)
				.orElseThrow(() -> new RuntimeException("Author not found with id " + authorId));

		Favorite favorite = new Favorite();
		favorite.setUser(user);
		favorite.setAuthor(author);

		favorite.setUsername(user.getUsername());
		favorite.setAuthorname(author.getName());

		favoriteRepository.save(favorite);
	}

	@Override
	public List<Author> getFavoriteAuthors(Long userId) {
		return favoriteRepository.findByUserId(userId).stream().map(Favorite::getAuthor).collect(Collectors.toList());
	}

	@Override
	public void removeAuthorFromFavorites(Long userId, Long authorId) {
		favoriteRepository.deleteByUserIdAndAuthorId(userId, authorId);
	}
}
