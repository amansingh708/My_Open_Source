package com.casestudy.aman.authorapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.aman.authorapp.entity.Author;
import com.casestudy.aman.authorapp.service.FavoriteService;



@RestController
@RequestMapping("/favorites")
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    
    @PostMapping("/users/{userId}/authors/{authorId}")
    public void addAuthorToFavorites(@PathVariable Long userId, @PathVariable Long authorId) {
        favoriteService.addAuthorToFavorites(userId, authorId);
    }

    
    @GetMapping("/users/{userId}/authors")
    public List<Author> getFavoriteAuthors(@PathVariable Long userId) {
        return favoriteService.getFavoriteAuthors(userId);
    }

   
    @DeleteMapping("/users/{userId}/authors/{authorId}")
    public void removeAuthorFromFavorites(@PathVariable Long userId, @PathVariable Long authorId) {
        favoriteService.removeAuthorFromFavorites(userId, authorId);
    }
}
