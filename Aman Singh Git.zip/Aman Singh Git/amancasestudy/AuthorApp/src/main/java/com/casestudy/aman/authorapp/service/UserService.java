package com.casestudy.aman.authorapp.service;

import java.util.Optional;

import com.casestudy.aman.authorapp.entity.User;

public interface UserService {
	    User registerUser(User user);
	  
		Optional<User> getUserById(Long id);
		User updateUser(User user);
		void deleteUserById(Long id);
	}


