package com.casestudy.aman.authorapp.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.casestudy.aman.authorapp.entity.Author;
import com.casestudy.aman.authorapp.service.FavoriteService;

@ExtendWith(MockitoExtension.class)
class FavoriteControllerTest {

    @Mock
    private FavoriteService favoriteService;

    @InjectMocks
    private FavoriteController favoriteController;

    @Test
    void addAuthorToFavorites_Success() {
        Long userId = 1L;
        Long authorId = 1L;

        favoriteController.addAuthorToFavorites(userId, authorId);

        verify(favoriteService).addAuthorToFavorites(userId, authorId);
    }

    @Test
    void getFavoriteAuthors_Success() {
        Long userId = 1L;

        Author author1 = new Author();
        author1.setId(1L);
        author1.setName("Author 1");

        Author author2 = new Author();
        author2.setId(2L);
        author2.setName("Author 2");

        when(favoriteService.getFavoriteAuthors(userId)).thenReturn(Arrays.asList(author1, author2));

        List<Author> favoriteAuthors = favoriteController.getFavoriteAuthors(userId);

        assertNotNull(favoriteAuthors);
        assertEquals(2, favoriteAuthors.size());
        assertEquals("Author 1", favoriteAuthors.get(0).getName());
        assertEquals("Author 2", favoriteAuthors.get(1).getName());
    }

    @Test
    void removeAuthorFromFavorites_Success() {
        Long userId = 1L;
        Long authorId = 1L;

        favoriteController.removeAuthorFromFavorites(userId, authorId);

        verify(favoriteService).removeAuthorFromFavorites(userId, authorId);
    }
}
