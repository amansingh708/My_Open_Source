package com.casestudy.aman.authorapp.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.casestudy.aman.authorapp.entity.User;
import com.casestudy.aman.authorapp.repository.UserRepository;
import com.casestudy.aman.authorapp.service.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

	@Mock
	UserRepository repository; // dependency

	@InjectMocks
	UserServiceImpl service; // dependent

	@Test
	void registerUser() {
		User user = new User();
		user.setId(2L);
		when(repository.save(user)).thenReturn(user);
		User newUser = service.registerUser(user);
		assertNotNull(newUser);
	}
	
	@Test
	void registerUser_UserAlreadyExists() {
	    User existingUser = new User();
	    existingUser.setUsername("existingUser");

	    when(repository.findByUsername("existingUser")).thenReturn(Optional.of(existingUser));

	    User newUser = new User();
	    newUser.setUsername("existingUser");

	    Exception exception = assertThrows(RuntimeException.class, () -> {
	        service.registerUser(newUser);
	    });

	    assertEquals("User with this username already exists", exception.getMessage());
	}
	
	@Test
	void getUserById_Success() {
	    User user = new User();
	    user.setId(1L);
	    when(repository.findById(1L)).thenReturn(Optional.of(user));

	    Optional<User> foundUser = service.getUserById(1L);
	    assertTrue(foundUser.isPresent());
	    assertEquals(1L, foundUser.get().getId());
	}
	
	@Test
	void getUserById_NotFound() {
	    when(repository.findById(1L)).thenReturn(Optional.empty());

	    Exception exception = assertThrows(RuntimeException.class, () -> {
	        service.getUserById(1L);
	    });

	    assertEquals("User not found", exception.getMessage());
	}
	
	@Test
	void updateUser_Success() {
	    User user = new User();
	    user.setId(1L);
	    user.setUsername("updatedUser");

	    when(repository.save(user)).thenReturn(user);

	    User updatedUser = service.updateUser(user);
	    assertNotNull(updatedUser);
	    assertEquals("updatedUser", updatedUser.getUsername());
	}
	
	@Test
	void deleteUserById_Success() {
	    service.deleteUserById(1L);

	    verify(repository).deleteById(1L);
	}



}
