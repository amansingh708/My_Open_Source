package com.casestudy.aman.authorapp.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.casestudy.aman.authorapp.entity.Author;
import com.casestudy.aman.authorapp.entity.Favorite;
import com.casestudy.aman.authorapp.entity.User;
import com.casestudy.aman.authorapp.repository.AuthorRepository;
import com.casestudy.aman.authorapp.repository.FavoriteRepository;
import com.casestudy.aman.authorapp.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
class FavoriteServiceImplTest {

    @Mock
    private FavoriteRepository favoriteRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private AuthorRepository authorRepository;

    @InjectMocks
    private FavoriteServiceImpl favoriteService;

   
    @Test
    void addAuthorToFavorites_Success() {
        User user = new User();
        user.setId(1L);
        user.setUsername("testUser");

        Author author = new Author();
        author.setId(1L);
        author.setName("testAuthor");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(authorRepository.findById(1L)).thenReturn(Optional.of(author));

        favoriteService.addAuthorToFavorites(1L, 1L);

        verify(favoriteRepository).save(any(Favorite.class));
    }

    @Test
    void addAuthorToFavorites_UserNotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            favoriteService.addAuthorToFavorites(1L, 1L);
        });

        assertEquals("User not found with id 1", exception.getMessage());
    }

    @Test
    void addAuthorToFavorites_AuthorNotFound() {
        User user = new User();
        user.setId(1L);
        user.setUsername("testUser");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(authorRepository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            favoriteService.addAuthorToFavorites(1L, 1L);
        });

        assertEquals("Author not found with id 1", exception.getMessage());
    }

    @Test
    void getFavoriteAuthors_Success() {
        User user = new User();
        user.setId(1L);

        Author author1 = new Author();
        author1.setId(1L);
        author1.setName("Author 1");

        Author author2 = new Author();
        author2.setId(2L);
        author2.setName("Author 2");

        Favorite favorite1 = new Favorite();
        favorite1.setUser(user);
        favorite1.setAuthor(author1);

        Favorite favorite2 = new Favorite();
        favorite2.setUser(user);
        favorite2.setAuthor(author2);

        when(favoriteRepository.findByUserId(1L)).thenReturn(Arrays.asList(favorite1, favorite2));

        List<Author> favoriteAuthors = favoriteService.getFavoriteAuthors(1L);

        assertNotNull(favoriteAuthors);
        assertEquals(2, favoriteAuthors.size());
        assertEquals("Author 1", favoriteAuthors.get(0).getName());
        assertEquals("Author 2", favoriteAuthors.get(1).getName());
    }

    @Test
    void removeAuthorFromFavorites_Success() {
        favoriteService.removeAuthorFromFavorites(1L, 1L);

        verify(favoriteRepository).deleteByUserIdAndAuthorId(1L, 1L);
    }
}