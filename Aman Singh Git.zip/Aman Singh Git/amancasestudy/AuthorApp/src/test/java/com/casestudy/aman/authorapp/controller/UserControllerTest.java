package com.casestudy.aman.authorapp.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;

import com.casestudy.aman.authorapp.entity.User;
import com.casestudy.aman.authorapp.service.UserService;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;
    
    @Test
    void registerUser_Success() {
        User user = new User();
        user.setUsername("newUser");

        when(userService.registerUser(any(User.class))).thenReturn(user);

        User registeredUser = userController.registerUser(user);

        assertNotNull(registeredUser);
        assertEquals("newUser", registeredUser.getUsername());
    }

    @Test
    void getUserById_Success() {
        User user = new User();
        user.setId(1L);

        when(userService.getUserById(1L)).thenReturn(Optional.of(user));

        Optional<User> foundUser = userController.getUserById(1L);

        assertNotNull(foundUser);
        assertEquals(1L, foundUser.get().getId());
    }
    
    @Test
    void getUserById_NotFound() {
        when(userService.getUserById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            userController.getUserById(1L)
                          .orElseThrow(() -> new RuntimeException("User not found with id 1"));
        });

        assertEquals("User not found with id 1", exception.getMessage());
    }
    
    @Test
    void updateUser_Success() {
        User user = new User();
        user.setId(1L);
        user.setUsername("existingUser");

        User updatedUserDetails = new User();
        updatedUserDetails.setUsername("updatedUser");

        when(userService.getUserById(1L)).thenReturn(Optional.of(user));
        when(userService.updateUser(any(User.class))).thenReturn(updatedUserDetails);

        User result = userController.updateUser(1L, updatedUserDetails);

        assertNotNull(result);
        assertEquals("updatedUser", result.getUsername());
    }
    
    @Test
    void updateUser_NotFound() {
        User updatedUserDetails = new User();
        updatedUserDetails.setUsername("updatedUser");

        when(userService.getUserById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            userController.updateUser(1L, updatedUserDetails);
        });

        assertEquals("User not found with id 1", exception.getMessage());
    }
    
    @Test
    void deleteUser_Success() {
        userController.deleteUser(1L);
        // No exception should be thrown
    }
    
    @Test
    void deleteUser_NotFound() {
        doThrow(new EmptyResultDataAccessException(1)).when(userService).deleteUserById(1L);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            userController.deleteUser(1L);
        });

        assertEquals("User not found with id 1", exception.getMessage());
    }


}
  

    
