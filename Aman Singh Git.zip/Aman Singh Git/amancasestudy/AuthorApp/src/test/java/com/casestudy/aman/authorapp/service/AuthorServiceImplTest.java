package com.casestudy.aman.authorapp.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.casestudy.aman.authorapp.entity.Author;
import com.casestudy.aman.authorapp.repository.AuthorRepository;

@ExtendWith(MockitoExtension.class)
class AuthorServiceImplTest {

    @Mock
    AuthorRepository repository; // dependency

    @InjectMocks
    AuthorServiceImpl service; // dependent

    @Test
    void saveAuthor_Success() {
        Author author = new Author();
        author.setId(1L);
        when(repository.save(author)).thenReturn(author);

        Author savedAuthor = service.saveAuthor(author);

        assertNotNull(savedAuthor);
        assertEquals(1L, savedAuthor.getId());
    }

    @Test
    void getAuthorById_Success() {
        Author author = new Author();
        author.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(author));

        Optional<Author> foundAuthor = service.getAuthorById(1L);

        assertTrue(foundAuthor.isPresent());
        assertEquals(1L, foundAuthor.get().getId());
    }

    @Test
    void getAuthorById_NotFound() {
        when(repository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            service.getAuthorById(1L);
        });

        assertEquals("Author not found", exception.getMessage());
    }

    @Test
    void updateAuthor_Success() {
        Author author = new Author();
        author.setId(1L);
        author.setName("Updated Author");

        when(repository.save(author)).thenReturn(author);

        Author updatedAuthor = service.updateAuthor(author);

        assertNotNull(updatedAuthor);
        assertEquals("Updated Author", updatedAuthor.getName());
    }

    @Test
    void deleteAuthorById_Success() {
        service.deleteAuthorById(1L);

        verify(repository).deleteById(1L);
    }
}



