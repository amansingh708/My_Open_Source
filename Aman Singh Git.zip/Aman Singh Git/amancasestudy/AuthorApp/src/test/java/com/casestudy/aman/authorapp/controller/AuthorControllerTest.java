package com.casestudy.aman.authorapp.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.casestudy.aman.authorapp.entity.Author;
import com.casestudy.aman.authorapp.service.AuthorService;

@ExtendWith(MockitoExtension.class)
class AuthorControllerTest {

    @Mock
    private AuthorService authorService;

    @InjectMocks
    private AuthorController authorController;

    @Test
    void addAuthor_Success() {
        Author author = new Author();
        author.setName("New Author");

        when(authorService.saveAuthor(any(Author.class))).thenReturn(author);

        Author result = authorController.addAuthor(author);

        assertNotNull(result);
        assertEquals("New Author", result.getName());
    }

    @Test
    void getAuthorById_Success() {
        Author author = new Author();
        author.setId(1L);

        when(authorService.getAuthorById(1L)).thenReturn(Optional.of(author));

        Optional<Author> result = authorController.getAuthorById(1L);

        assertNotNull(result);
        assertEquals(1L, result.get().getId());
    }

    @Test
    void getAuthorById_NotFound() {
        when(authorService.getAuthorById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            authorController.getAuthorById(1L).orElseThrow(() -> new RuntimeException("Author not found with id 1"));
        });

        assertEquals("Author not found with id 1", exception.getMessage());
    }

    @Test
    void updateAuthor_Success() {
        Author existingAuthor = new Author();
        existingAuthor.setId(1L);
        existingAuthor.setName("Existing Author");

        Author updatedAuthorDetails = new Author();
        updatedAuthorDetails.setName("Updated Author");

        when(authorService.getAuthorById(1L)).thenReturn(Optional.of(existingAuthor));
        when(authorService.updateAuthor(any(Author.class))).thenReturn(updatedAuthorDetails);

        Author result = authorController.updateAuthor(1L, updatedAuthorDetails);

        assertNotNull(result);
        assertEquals("Updated Author", result.getName());
    }

    @Test
    void updateAuthor_NotFound() {
        Author updatedAuthorDetails = new Author();
        updatedAuthorDetails.setName("Updated Author");

        when(authorService.getAuthorById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            authorController.updateAuthor(1L, updatedAuthorDetails);
        });

        assertEquals("Author not found with id 1", exception.getMessage());
    }

    @Test
    void deleteAuthor_Success() {
        authorController.deleteAuthor(1L);
        verify(authorService).deleteAuthorById(1L);
    }

    @Test
    void deleteAuthor_NotFound() {
        doThrow(new RuntimeException("Author not found with id 1")).when(authorService).deleteAuthorById(1L);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            authorController.deleteAuthor(1L);
        });

        assertEquals("Author not found with id 1", exception.getMessage());
    }
    
   
    
    
    

}












